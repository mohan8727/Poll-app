import { Component } from '@angular/core';
import { Poll, PollForm, PollVote } from './types';
import { PollService } from './poll-service/poll.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'poll-app';

  showForm: boolean = false;
  selectedPoll: Poll = null;

  setSelectedPoll(poll) {
    this.selectedPoll = null;
    setTimeout(() => {
      this.selectedPoll = poll;
    }, 100);
  }

  handlePollVote(vote: PollVote) {
    this.ps.vote(vote.id, vote.vote);
  }

  handlePollCreate(poll: PollForm) {
    this.ps.createPoll(poll);
  }

  polls = this.ps.getPolls();

  constructor(private ps: PollService) {}
}
