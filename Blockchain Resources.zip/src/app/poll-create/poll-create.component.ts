import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PollForm } from '../types';

@Component({
  selector: 'app-poll-create',
  templateUrl: './poll-create.component.html',
  styleUrls: ['./poll-create.component.scss'],
})
export class PollCreateComponent {
  @Output() pollCreated: EventEmitter<PollForm> = new EventEmitter();

  id: number;
  pollForm: FormGroup;
  constructor(private fb: FormBuilder) {
    this.pollForm = this.fb.group({
      question: this.fb.control('', [Validators.required]),
      thumbnail: this.fb.control(''),
      option1: this.fb.control(''),
      option2: this.fb.control(''),
      option3: this.fb.control(''),
      option4: this.fb.control(''),
    });
  }

  submitPoll() {
    const formDataFromUser = {
      question: this.pollForm.get('question').value,
      thumbnail: this.pollForm.get('thumbnail').value,
      options: [
        this.pollForm.get('option1').value,
        this.pollForm.get('option2').value,
        this.pollForm.get('option3').value,
        this.pollForm.get('option4').value,
      ],
    };
    this.pollCreated.emit(formDataFromUser);
  }
}
