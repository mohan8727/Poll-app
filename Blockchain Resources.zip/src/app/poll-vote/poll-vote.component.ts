import {
  Component,
  OnInit,
  Input,
  AfterViewInit,
  EventEmitter,
  Output,
} from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import ApexCharts from 'apexcharts';
import { PollVote } from '../types';

@Component({
  selector: 'app-poll-vote',
  templateUrl: './poll-vote.component.html',
  styleUrls: ['./poll-vote.component.scss'],
})
export class PollVoteComponent implements AfterViewInit {
  @Input() id: number;
  @Input() voted: boolean;
  @Input() question: string;
  @Input() thumbnail: string;
  @Input() options: string[];
  @Input() votes: number[];

  @Output() pollVoted: EventEmitter<PollVote> = new EventEmitter();

  voteForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.voteForm = this.fb.group({
      selected: this.fb.control('', [Validators.required]),
    });
  }

  submitVote() {
    const formDataFromUser = {
      id: this.id,
      vote: this.voteForm.get('selected').value,
    };
    this.pollVoted.emit(formDataFromUser);
  }

  generateChart() {
    let options: ApexCharts.ApexOptions = {
      chart: {
        type: 'bar',
      },
      series: [
        {
          name: 'Votes',
          data: this.votes,
        },
      ],
      xaxis: {
        categories: this.options,
      },
    };

    var chart = new ApexCharts(document.querySelector('#vote-result'), options);
    chart.render();
  }

  ngAfterViewInit(): void {
    if (this.voted) {
      this.generateChart();
    }
  }
}
